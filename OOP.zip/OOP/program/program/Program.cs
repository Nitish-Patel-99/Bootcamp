﻿using System;
class ClassObjectdemo
{
    public int a;
}

struct StructRefDemo
{
    public int b;
}

public class Encapsulation
{
    private int pr;
    protected int prot;
    public int pu;

    public Encapsulation()
    {
        pr = 100;
    }

    public void AccessibleDemo()
    {
        pr = 10;
        prot = 50;
        pu = 90;
    }
}

class EncapsulationAndInheritanceDemo:Encapsulation
{
    public void AccessibleDemoOfDirectChild()
    {
        prot = 40;
        pu = 60;
    }
}

class Polymorphism_FunctionOverloading
{
    public void demo()
    {
        Console.WriteLine("1st demo function  in Polymorphism_FunctionOverloading class - no return type , no parameter.");
    }

    public void demo(int x)
    {
        Console.WriteLine("2nd demo function  in Polymorphism_FunctionOverloading class - no return type , 1 integer parameter.");
    }

    public void demo(int y ,char z)
    {
        Console.WriteLine("3rd demo function  in Polymorphism_FunctionOverloading class - no return type , 1 integer + 1 character parameter.");
    }
}

class Base_Cls
{
    public virtual void DemoFunction()
    {
        Console.WriteLine("Base class says Hello..!");
    }

    public void DemoFunction2()
    {
        Console.WriteLine("Base class says Hello second time");
    }
}

class Derived_Cls : Base_Cls
{
    public override void DemoFunction()
    {
        base.DemoFunction();
        Console.WriteLine("Derived class says Hello..!!");
    }

    public void DemoFunction2()
    {
        Console.WriteLine("Derived class says Hello second time");
    }
}

class Derived_Sub_Cls : Derived_Cls
{
    public override void DemoFunction()
    {
        base.DemoFunction();
        Console.WriteLine("Derived_Sub_Cls Saying Hello!");
    }
    public void DemoFunction2()
    {
        Console.WriteLine("Derived_Sub_Cls Saying Hello second time!");
    }
}

abstract class Parent_AbCls
{
    public abstract void DemoParentAbsAbstract();

    public void DemoParentAbsNormal()
    {
        Console.WriteLine("Normal Method of Normal Class Named - Parent_AbsCls is called.");
    }
}

abstract class Abstract_Cls : Parent_AbCls
{
    public abstract void DemoABS();
    public void DemoNormal()
    {
        Console.WriteLine("Normal Method of Abstract Class Named - Abstract_CLS is called.");
    }

    public override void DemoParentAbsAbstract()
    {
        Console.WriteLine("Abstract Method of Abstract Class Named - Parent_AbsCls is called IN Abstract_CLS.");
    }
}

class ChildCls_AbsDemo : Abstract_Cls
{
    public override void DemoABS()
    {
        Console.WriteLine("Abstract Method of Abstract Class Named - Abstract_CLS is called.");
    }
    public void DemoChildNormal()
    {
        Console.WriteLine("Normal Method of Child Class Named - ChildCLS_AbsDemo is called.");
    }

    public override void DemoParentAbsAbstract()
    {
        Console.WriteLine("Abstract Method of Abstract Class Named - Parent_AbsCls is called IN ChildCLS_AbsDemo.");
    }
}

interface IParent1
{
    void IAbsDemo();
}
interface IParent2
{
    void IAbsDemo();
}
class InterfaceDemo_CLS : IParent1, IParent2
{
    void IParent1.IAbsDemo()
    {
        Console.WriteLine("Interface IParent Method Override.");
    }
    void IParent2.IAbsDemo()
    {
        Console.WriteLine("Interface IParent2 Method Override.");
    }
}
class InterfaceDemo_CLS2 : IParent1, IParent2
{

    void IParent1.IAbsDemo()
    {
        Console.WriteLine("Interface IParent Method Override.");
    }
    void IParent2.IAbsDemo()
    {
        Console.WriteLine("Interface IParent2 Method Override.");
    }
}
class program
{
    static void Main(String[] args)
    {
        ClassObjectdemo c1 = new ClassObjectdemo();
        ClassObjectdemo c2 = new ClassObjectdemo();
        ClassObjectdemo c3 = c1;
        ClassObjectdemo c4 = c2;
        c1.a = 1;
        c2.a = 20;
        c3.a = 30;
        c4.a = 50;
        Console.WriteLine("Value of c1.a=" + c1.a);
        Console.WriteLine("Value of c2.a=" + c2.a);
        Console.WriteLine("Value of c3.a=" + c3.a);
        Console.WriteLine("Value of c4.a=" + c4.a);

        StructRefDemo s1 = new StructRefDemo();
        StructRefDemo s2 = new StructRefDemo();
        StructRefDemo s3 = new StructRefDemo();
        StructRefDemo s4 = s3;
        StructRefDemo s5 = s1;
        StructRefDemo s6 = s2;
        StructRefDemo s7 = s4;

        s1.b = 10;
        s2.b = 25;
        s3.b = 60;
        s4.b = 90;
        s5.b = 100;
        s6.b = 120;
        s7.b = 140;

        Console.WriteLine("value of s1.b=" + s1.b);
        Console.WriteLine("value of s2.b=" + s2.b);
        Console.WriteLine("value of s3.b=" + s3.b);
        Console.WriteLine("value of s4.b=" + s4.b);
        Console.WriteLine("value of s5.b=" + s5.b);
        Console.WriteLine("value of s6.b=" + s6.b);
        Console.WriteLine("value of s7.b=" + s7.b);

        Encapsulation e1 = new Encapsulation();
        e1.pu = 100;

        EncapsulationAndInheritanceDemo ei1 = new EncapsulationAndInheritanceDemo();
        ei1.pu = 121;

        Console.WriteLine("Publice Variable Value:" + e1.pu + "-" + ei1.pu );

        Polymorphism_FunctionOverloading PolyOverLoading = new Polymorphism_FunctionOverloading();
        PolyOverLoading.demo();
        PolyOverLoading.demo(10);
        PolyOverLoading.demo(100, 'N');

        Base_Cls B_Cls = new Base_Cls();
        B_Cls.DemoFunction();
        B_Cls.DemoFunction2();

        Derived_Cls D_Cls = new Derived_Cls();
        D_Cls.DemoFunction();
        D_Cls.DemoFunction2();

       Derived_Sub_Cls D_Sub_Cls = new Derived_Sub_Cls();
       D_Sub_Cls.DemoFunction();
       D_Sub_Cls.DemoFunction2();

       ChildCls_AbsDemo CCLS_AbsDemo = new ChildCls_AbsDemo();
       CCLS_AbsDemo.DemoNormal();
       CCLS_AbsDemo.DemoABS();
       CCLS_AbsDemo.DemoChildNormal();
       CCLS_AbsDemo.DemoParentAbsNormal();
       CCLS_AbsDemo.DemoParentAbsAbstract();

        Abstract_Cls AbCLS = new ChildCls_AbsDemo();
        AbCLS.DemoNormal();
        AbCLS.DemoNormal();
        AbCLS.DemoParentAbsNormal();
        AbCLS.DemoParentAbsAbstract();

        IParent1 ICls = new InterfaceDemo_CLS();
        ICls.IAbsDemo();

        ICls = new InterfaceDemo_CLS2();
        ICls.IAbsDemo();

        IParent2 ICls2 = new InterfaceDemo_CLS();
        ICls2.IAbsDemo();

    }
}